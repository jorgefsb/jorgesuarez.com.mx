// cuaderno.typ · Plantilla «Cuaderno de campo» (estilo C)
// Uso exclusivo: documentos y reportes de la marca personal JorgeSuarez.com.mx.
// Importar: #import "cuaderno.typ": *
// Compilar: typst compile --root <carpeta> --font-path <carpeta>/fonts ejemplo.typ salida.pdf
// Las rutas de imagen que se pasan como texto se resuelven desde esta carpeta.

// ---------- Tokens de marca ----------
#let naranja       = rgb("#FF6B35")
#let naranja-tinta = rgb("#C2461A")   // naranja oscurecido para trazos y notas legibles
#let ambar         = rgb("#FFA500")
#let papel         = rgb("#F4E8D5")
#let hoja          = rgb("#FCF7EE")
#let kraft         = rgb("#B99168")
#let tinta         = rgb("#22211F")
#let suave         = rgb("#58524A")
#let reticula      = rgb("#E3D6BF")
#let post-amarillo = rgb("#FFE7B8")
#let post-crema    = rgb("#FFF1D6")

#let f-mano   = "Caveat"
#let f-nota   = "Kalam"
#let f-titulo = "Outfit"
#let f-texto  = "Inter"

#let jit = (0.8, -0.6, 1.1, -1.0, 0.5, -0.9, 0.7, -0.4, 1.0, -0.7, 0.3, -1.1)
#let trazo   = (paint: tinta, thickness: 1.1pt, cap: "round", join: "round")
#let trazo-n = (paint: naranja-tinta, thickness: 1.3pt, cap: "round", join: "round")

// Límite de giro para fotos, notas y Moki
#let giro-max = 8deg
#let _giro(r) = if r > giro-max { giro-max } else if r < -giro-max { -giro-max } else { r }

// Acepta una ruta (texto) o contenido image(...) ya construido
#let _img(src, width: 100%) = if type(src) == str { image(src, width: width) } else { src }

// Formato de miles: 11600 -> 11,600
#let miles(n) = {
  let s = str(calc.abs(int(n)))
  let out = ""
  let k = 0
  for i in range(s.len() - 1, -1, step: -1) {
    out = s.at(i) + out
    k += 1
    if calc.rem(k, 3) == 0 and i > 0 { out = "," + out }
  }
  if n < 0 { "-" + out } else { out }
}

// ---------- Texto con carácter ----------
#let mano(t, size: 13pt, fill: naranja-tinta) = text(font: f-mano, size: size, fill: fill)[#t]
#let nota(t, size: 9.5pt, fill: tinta) = text(font: f-nota, size: size, fill: fill)[#t]
#let en(t, size: 8.5pt) = text(style: "italic", size: size, fill: suave)[#t]

#let ejemplo = box(inset: (x: 5pt, y: 4pt), stroke: (paint: tinta, thickness: 0.8pt, dash: "dashed"), radius: 2pt,
  text(font: f-titulo, weight: 700, size: 6.8pt, tracking: 0.8pt, fill: tinta)[DATOS DE EJEMPLO · EXAMPLE DATA])

// ---------- Trazos a mano ----------
#let caja-mano(w, h, fill: none, k: 0) = {
  let j(i) = jit.at(calc.rem(i + k, jit.len())) * 1pt
  box(width: w, height: h, {
    place(polygon(fill: fill, stroke: trazo, (j(0), j(1)), (w + j(2), j(3)), (w + j(4), h + j(5)), (j(6), h + j(7))))
    place(polygon(stroke: (paint: tinta.transparentize(45%), thickness: 0.6pt), (j(3) - 1pt, j(8)), (w + j(9) + 1pt, j(0) + 1pt), (w + j(1), h + j(2) + 1pt), (j(5), h + j(10))))
  })
}

#let subrayado(w, color: naranja-tinta) = box(width: w, height: 5pt,
  curve(stroke: (paint: color, thickness: 1.6pt, cap: "round"),
    curve.move((0pt, 3pt)), curve.quad((w * 0.45, 0pt), (w, 2.5pt))))

#let flecha(w, h, color: naranja-tinta, izq: false) = box(width: w, height: h, {
  let (x0, x1) = if izq { (w, 0pt) } else { (0pt, w) }
  let s = if izq { -1 } else { 1 }
  place(curve(stroke: (paint: color, thickness: 1.3pt, cap: "round"),
    curve.move((x0, 0pt)), curve.quad((x0 + s * w * 0.15, h * 0.9), (x1, h))))
  place(curve(stroke: (paint: color, thickness: 1.3pt, cap: "round"),
    curve.move((x1 - s * 7pt, h - 5pt)), curve.line((x1, h)), curve.line((x1 - s * 6pt, h + 5pt))))
})

#let palomita = box(width: 11pt, height: 10pt, place(curve(stroke: (paint: naranja-tinta, thickness: 1.8pt, cap: "round", join: "round"),
  curve.move((1pt, 5pt)), curve.line((4.5pt, 9pt)), curve.line((12pt, -2pt)))))

// ---------- Cinta adhesiva (curita) ----------
// Solo para sujetar algo: una foto, una nota. Bordes dentados como cinta rasgada.
#let cinta(w: 0.8in, h: 0.22in, rot: 0deg) = rotate(_giro(rot), reflow: false, box(width: w, height: h, {
  let d = 2.2pt
  let n = 5
  let izq = range(n + 1).map(i => (if calc.rem(i, 2) == 0 { 0pt } else { d }, h * i / n))
  let der = range(n + 1).rev().map(i => (if calc.rem(i, 2) == 0 { w } else { w - d }, h * i / n))
  place(polygon(fill: kraft.transparentize(42%), stroke: none, ..izq, ..der))
}))

// ---------- Fondo: hoja punteada con perforaciones ----------
#let fondo = {
  place(top + left, dx: 0.62in, dy: 0.5in, rect(width: 7.38in, height: 10in, stroke: none,
    fill: tiling(size: (0.25in, 0.25in))[#place(dx: 0.125in, dy: 0.125in, circle(radius: 0.55pt, fill: reticula))]))
  place(top + left, dx: 0.85in, line(length: 11in, angle: 90deg, stroke: 0.7pt + naranja.transparentize(55%)))
  for i in range(14) { place(top + left, dx: 0.22in, dy: 0.55in + i * 0.72in, circle(radius: 0.085in, fill: white, stroke: 0.6pt + reticula)) }
}

// ---------- Plantilla de documento ----------
// bitacora: texto del encabezado, se antepone «Bitácora · »
// pie: texto del pie izquierdo (en mayúsculas)
#let cuaderno(titulo: "", autor: "Jorge Suárez", bitacora: "", encabezado-der: "", pie: "JORGE SUÁREZ · JORGESUAREZ.COM.MX", doc) = {
  set document(title: titulo, author: autor)
  set text(font: f-texto, size: 10.2pt, fill: tinta, lang: "es")
  set par(justify: false, leading: 0.7em, spacing: 0.95em)
  show strong: it => text(font: f-titulo, weight: 700, it.body)
  show link: it => underline(stroke: 1.2pt + naranja, offset: 2pt, it)
  set page(
    paper: "us-letter",
    fill: hoja,
    background: fondo,
    margin: (top: 0.9in, bottom: 0.85in, left: 1.15in, right: 0.75in),
    header: context {
      if counter(page).get().first() > 1 {
        grid(columns: (1fr, auto), align: (left + bottom, right + bottom),
          mano([Bitácora · #bitacora], size: 13pt, fill: suave),
          text(font: f-titulo, weight: 700, size: 7.5pt, tracking: 1pt, fill: suave)[#upper(encabezado-der)])
      }
    },
    footer: context {
      let n = counter(page).get().first()
      if n > 1 {
        grid(columns: (1fr, auto), align: (left + horizon, right + horizon),
          text(font: f-titulo, weight: 700, size: 7pt, tracking: 0.8pt, fill: suave)[#pie],
          box(inset: (x: 4pt), mano([pág. #n], size: 14pt, fill: tinta)))
      }
    },
  )
  doc
}

// ---------- Títulos ----------
#let entrada-titulo(fecha, es, en-t) = block(below: 8pt)[
  #text(font: f-titulo, weight: 700, size: 8pt, tracking: 1.4pt, fill: suave)[#upper(fecha)]
  #v(-2pt)
  #text(font: f-titulo, weight: 700, size: 24pt)[#es]
  #v(-12pt)
  #subrayado(2.6in)
  #v(-6pt)
  #mano(en-t, size: 15pt, fill: suave)
]

#let sub(es, en-t) = block(above: 12pt, below: 5pt, breakable: false)[
  #text(font: f-titulo, weight: 700, size: 12pt)[#es] #h(5pt) #mano(en-t, size: 13pt, fill: suave)
]

// ---------- Nota adhesiva: una cinta arriba al centro la sostiene ----------
#let post-it(width: 100%, rot: -1.5deg, fill: post-amarillo, body) = rotate(_giro(rot), reflow: true, box(width: width, {
  block(width: 100%, fill: fill, inset: 11pt, stroke: (paint: rgb("#D9B97A"), thickness: 0.6pt), body)
  place(top + center, dy: -9pt, cinta(w: 0.85in, rot: 2deg))
}))

// Nota de datos: filas = ((valor, etiqueta), ...)
#let nota-datos(titulo, titulo-en, filas, rot: -2deg, width: 100%, fill: post-amarillo, con-ejemplo: true) = post-it(width: width, rot: rot, fill: fill)[
  #mano(titulo, size: 17pt, fill: tinta)
  #v(-6pt)
  #en(titulo-en, size: 7.5pt)
  #v(2pt)
  #grid(columns: (auto, 1fr), row-gutter: 6pt, column-gutter: 8pt, align: (right + bottom, left + bottom),
    ..filas.map(f => (text(font: f-titulo, weight: 700, size: 15pt)[#f.at(0)], nota(f.at(1), size: 8.5pt))).flatten())
  #if con-ejemplo { v(4pt); ejemplo }
]

// ---------- Checklist ----------
// items = ((hecho, texto-es, texto-en o none), ...)
#let check(hecho, body, k: 0) = grid(columns: (16pt, 1fr), column-gutter: 6pt, align: (left + top, left + top),
  box(width: 12pt, height: 12pt, inset: (top: 1pt), { place(top + left, caja-mano(10pt, 10pt, fill: white, k: k)); if hecho { place(top + left, dy: -1pt, palomita) } }),
  body)

#let checklist(items, espacio: 4pt) = {
  for (i, it) in items.enumerate() {
    check(it.at(0), k: i * 3, [#it.at(1) #if it.len() > 2 and it.at(2) != none [#h(2pt) #en(it.at(2))]])
    v(espacio, weak: true)
  }
}

// ---------- Foto pegada con cinta ----------
// img: ruta o image(...). Dos cintas en las esquinas superiores sostienen la foto.
#let foto(img, width: 2.4in, rot: 2deg, pie: none, fondo-foto: white) = rotate(_giro(rot), reflow: true, box(width: width, {
  block(width: 100%, fill: white, stroke: 0.7pt + rgb("#CFC2AC"), inset: (x: 7pt, top: 7pt, bottom: if pie != none { 3pt } else { 7pt }), {
    block(width: 100%, fill: fondo-foto, clip: true, _img(img))
    if pie != none { align(center, mano(pie, size: 13pt, fill: tinta)) }
  })
  place(top + left, dx: -0.22in, dy: -0.07in, cinta(w: 0.62in, rot: -6deg))
  place(top + right, dx: 0.22in, dy: -0.07in, cinta(w: 0.62in, rot: 6deg))
}))

// ---------- Moki asoma por el borde superior de una caja ----------
// Reserva el espacio de Moki arriba de la caja: nunca tapa texto.
// La caja se dibuja después de la imagen y oculta el corte inferior.
#let moki-asoma(body, moki: "assets/moki-front-peek.png", ancho-moki: 1.15in, lado: right, dx: -0.35in, fill: white, etiqueta: none) = context {
  let img = _img(moki, width: ancho-moki)
  let s = measure(img)
  block(above: s.height + 8pt, width: 100%, breakable: false, {
    place(top + lado, dx: dx, dy: -s.height + 3pt, img)
    block(width: 100%, fill: fill, stroke: trazo, inset: (x: 13pt, y: 12pt), {
      if etiqueta != none { mano(etiqueta, size: 16pt); v(-6pt) }
      body
    })
  })
}

// ---------- Moki señala la idea clave ----------
// Moki a la izquierda mirando hacia el texto, con flecha a mano hacia la idea.
#let moki-senala(body, moki: "assets/moki-34-right.png", ancho-moki: 0.95in, etiqueta: [Moki señala:]) = block(breakable: false, width: 100%,
  grid(columns: (ancho-moki, 0.45in, 1fr), column-gutter: 4pt, align: (left + horizon, center + horizon, left + horizon),
    _img(moki, width: ancho-moki),
    flecha(0.42in, 0.12in),
    block(width: 100%, inset: (left: 10pt, y: 6pt), stroke: (left: 2.5pt + naranja-tinta), [
      #mano(etiqueta, size: 15pt)
      #v(-6pt)
      #body
    ]),
  ))

// ---------- Nota al margen ----------
#let nota-margen(t, t-en: none, size: 11pt) = block(breakable: false, [
  #nota(t, size: size, fill: naranja-tinta)
  #if t-en != none { v(-6pt); en(t-en, size: 8pt) }
  #v(-4pt)
  #flecha(0.8in, 0.18in)
])

// ---------- Gráfica de barras a mano ----------
// datos = ((etiqueta, valor), ...). resaltar = índice de la barra clave (trama densa y etiqueta, legible en gris).
#let grafica-barras(datos, alto: 2.6in, resaltar: none, formato: v => str(v), nota-clave: none, pie: none, con-ejemplo: true) = layout(size => {
  let W = size.width
  let H = alto
  box(width: W, height: H, {
    place(top + left, caja-mano(W, H, fill: hoja, k: 1))
    let n = datos.len()
    let base = H - 0.5in
    let mx = calc.max(..datos.map(d => d.at(1)))
    let bw = calc.min(0.7in, (W - 0.6in) / (n * 1.6))
    let gap = if n > 1 { (W - 0.6in - n * bw) / (n - 1) } else { 0pt }
    let top-reserva = if nota-clave != none { 0.75in } else { 0.45in }
    for (i, d) in datos.enumerate() {
      let h = (base - top-reserva) * d.at(1) / mx
      let x = 0.3in + i * (bw + gap)
      let clave = resaltar == i
      let j(m) = jit.at(calc.rem(i * 3 + m, jit.len())) * 1pt
      place(top + left, dx: x, dy: base - h, polygon(
        fill: tiling(size: if clave { (3.5pt, 3.5pt) } else { (5pt, 5pt) })[#place(line(start: (0pt, if clave { 3.5pt } else { 5pt }), end: (if clave { 3.5pt } else { 5pt }, 0pt), stroke: (paint: if clave { naranja-tinta } else { kraft }, thickness: if clave { 1.2pt } else { 0.8pt })))],
        stroke: if clave { (paint: tinta, thickness: 1.8pt, cap: "round", join: "round") } else { trazo },
        (j(0), j(1)), (bw + j(2), j(3)), (bw + j(4), h), (j(5), h)))
      place(top + left, dx: x - 0.15in, dy: base - h - 0.27in, box(width: bw + 0.3in, align(center, mano(formato(d.at(1)), size: 14pt, fill: if clave { naranja-tinta } else { tinta }))))
      place(top + left, dx: x - 0.1in, dy: base + 0.06in, box(width: bw + 0.2in, align(center, nota(d.at(0), size: 9.5pt))))
    }
    place(top + left, dx: 0.2in, dy: base, curve(stroke: trazo, curve.move((0pt, 0pt)), curve.quad((W / 2, 1.5pt), (W - 0.4in, -0.5pt))))
    if nota-clave != none { place(top + left, dx: 0.3in, dy: 0.16in, box(width: W - 0.6in, nota(nota-clave, size: 10.5pt, fill: naranja-tinta))) }
    if con-ejemplo { place(bottom + right, dx: -0.12in, dy: -0.1in, ejemplo) }
    if pie != none { place(bottom + left, dx: 0.15in, dy: -0.12in, text(size: 7.5pt, fill: suave)[#pie]) }
  })
})

// ---------- Portada de capítulo ----------
#let portada(capitulo: "Capítulo 01", capitulo-en: "Chapter 01", titulo: [], titulo-en: [], lema: none, lema-en: none,
  imagen: none, pie-imagen: none, nota-imagen: none, checks: (), marca: "assets/JorgeSuarez-B-claro-bicolor.svg",
  linea-final: none, con-ejemplo: false) = page(header: none, footer: none)[
  #grid(columns: (1fr, auto), align: (left + top, right + top),
    box(stroke: 1.4pt + tinta, inset: (x: 8pt, y: 5pt), radius: 3pt, text(font: f-titulo, weight: 700, size: 9pt, tracking: 1.6pt)[BITÁCORA DE CAMPO · FIELD LOG]),
    if con-ejemplo { ejemplo },
  )
  #v(0.3in)
  #mano([#capitulo / #capitulo-en], size: 30pt)
  #v(-0.18in)
  #text(font: f-titulo, weight: 700, size: 42pt)[#titulo]
  #v(-0.28in)
  #subrayado(4.4in)
  #v(-0.12in)
  #mano(titulo-en, size: 26pt, fill: suave)
  #v(0.2in)
  #grid(columns: (3.7in, 1fr), column-gutter: 0.3in, align: (left + top, left + top),
    if imagen != none { v(0.15in); foto(imagen, width: 3.7in, rot: -2deg, pie: pie-imagen) },
    [
      #v(0.3in)
      #if nota-imagen != none { nota(nota-imagen, size: 12pt); v(-4pt); flecha(1.0in, 0.4in, izq: true) }
      #v(0.1in)
      #if lema != none { text(font: f-titulo, weight: 700, size: 15pt)[#lema]; v(-6pt) }
      #if lema-en != none { mano(lema-en, size: 17pt, fill: suave) }
      #v(0.18in)
      #for (i, c) in checks.enumerate() { check(c.at(0), nota(c.at(1)), k: i * 3); v(-2pt) }
    ],
  )
  #place(bottom + left, dy: 0.1in, grid(columns: (auto, 1fr), column-gutter: 12pt, align: horizon,
    image(marca, width: 1.7in),
    if linea-final != none { mano(linea-final, size: 14pt, fill: suave) }))
]

// ---------- Índice ----------
// entradas = ((num, es, en, pag, hecho), ...)
#let indice(entradas) = {
  for (i, e) in entradas.enumerate() {
    block(below: 18pt, breakable: false)[
      #grid(columns: (16pt, 0.35in, 1fr, auto), column-gutter: 6pt, align: (left + horizon, left + horizon, left + horizon, right + horizon),
        box(width: 12pt, height: 12pt, { place(top + left, caja-mano(10pt, 10pt, fill: white, k: i * 2)); if e.at(4) { place(top + left, dy: -1pt, palomita) } }),
        mano(e.at(0), size: 18pt, fill: naranja-tinta),
        [#text(font: f-titulo, weight: 700, size: 12pt)[#e.at(1)] #h(4pt) #mano(e.at(2), size: 14pt, fill: suave)],
        mano([pág. #e.at(3)], size: 15pt, fill: tinta),
      )
      #v(-8pt)
      #line(length: 100%, stroke: (paint: reticula.darken(10%), thickness: 0.7pt))
    ]
  }
}

// ---------- Renglones para notas a mano ----------
#let renglones(n, sep: 0.26in) = for i in range(n) { v(sep); line(length: 100%, stroke: (paint: reticula.darken(15%), thickness: 0.7pt)) }

// ---------- Pie de cierre con enlace y firma ----------
#let cierre-pie(texto: [más bitácoras y aprendizajes en], marca: "assets/JorgeSuarez-B-claro-bicolor.svg") = {
  v(1fr)
  line(length: 100%, stroke: (paint: tinta, thickness: 0.8pt, dash: "dashed"))
  v(2pt)
  grid(columns: (auto, 1fr, auto), column-gutter: 12pt, align: (left + horizon, center + horizon, right + horizon),
    image(marca, width: 1.5in),
    mano(texto, size: 14pt, fill: suave),
    text(font: f-titulo, weight: 700, size: 11pt)[#link("https://jorgesuarez.com.mx")[jorgesuarez.com.mx]])
}

#let firma(nombre: "Jorge") = align(right, block[
  #mano(nombre, size: 30pt, fill: tinta)
  #v(-0.28in)
  #subrayado(1in)
])
