// ejemplo.typ · Muestra de la plantilla «Cuaderno de campo»
// Todos los datos son de ejemplo y cuadran entre sí.
#import "cuaderno.typ": *

// ---------- Datos de ejemplo: primer mes del devlog ----------
#let visitas   = (("sem 1", 1200), ("sem 2", 2100), ("sem 3", 3400), ("sem 4", 4900))
#let wishlists = (85, 140, 230, 345)
#let total-visitas = visitas.map(d => d.at(1)).sum()          // 11,600
#let total-wl = wishlists.sum()                                // 800
#let conv(v, w) = {
  let r = calc.round(w / v * 100, digits: 1)
  if r == calc.floor(r) { str(int(r)) + ".0%" } else { str(r) + "%" }
}

#show: cuaderno.with(
  titulo: "El primer mes del devlog · The devlog's first month",
  bitacora: "capítulo 02 · el primer mes del devlog",
  encabezado-der: "Muestra de plantilla",
  pie: "JORGE SUÁREZ · DATOS DE EJEMPLO",
)

// ---------- 1 · Portada ----------
#portada(
  capitulo: "Capítulo 02", capitulo-en: "Chapter 02",
  titulo: [El primer mes \ del devlog],
  titulo-en: [The devlog's first month],
  lema: [Escribir en público también es construir],
  lema-en: [Building in public, one entry at a time],
  imagen: "assets/moki-v001-escribe-bitacora.jpg",
  pie-imagen: [Moki abre la bitácora],
  nota-imagen: [Cada semana, una entrada nueva.],
  checks: ((true, [4 devlogs publicados]), (true, [Visitas y wishlists medidas]), (false, [Siguiente ruta trazada])),
  linea-final: [Juego de ejemplo · octubre 2026],
  con-ejemplo: true,
)

// ---------- 2 · Índice ----------
#entrada-titulo("Índice · Contents", "Lo que hay en este capítulo", "What's in this chapter")
#v(0.2in)
#indice((
  ("01", "Cuatro semanas, cuatro devlogs", "four weeks, four devlogs", 3, true),
  ("02", "Visitas por semana", "weekly visits", 3, true),
  ("03", "La primera cima: 800 wishlists", "the first summit", 4, true),
  ("04", "Lo que aprendí", "what I learned", 4, false),
  ("05", "La siguiente ruta", "the next route", 5, false),
))

#v(0.15in)
#moki-asoma(etiqueta: [Cómo leer esta bitácora], fill: post-crema)[
  #nota[Cada página es una entrada: qué pasó, qué medí y qué voy a probar. Las palomitas marcan lo que ya revisé. Los números son de ejemplo y cuadran entre sí.]
  #v(-2pt)
  #en[How to read this log: one entry per page, what happened, what I measured, what I will try next.]
]

#v(0.12in)
#sub("El mes de un vistazo", "the month at a glance")
#grid(columns: (1fr, 1fr, 1fr), column-gutter: 0.25in,
  ..(([#miles(total-visitas)], [visitas · visits]), ([#total-wl], [wishlists]), ([#conv(total-visitas, total-wl)], [visita a wishlist · conversion])).map(x => block(width: 100%, inset: (y: 4pt), [
    #text(font: f-titulo, weight: 700, size: 22pt)[#x.at(0)] \
    #v(-8pt)
    #nota(x.at(1), size: 10pt)
  ])))
#align(right, ejemplo)

#v(0.2in)
#sub("Mis notas", "my notes")
#renglones(3)

#pagebreak(weak: true)

// ---------- 3 · Texto, datos y gráfica ----------
#entrada-titulo("Entrada 01 · lunes 12 de octubre, 2026", "Cuatro semanas, cuatro devlogs", "Four weeks, four devlogs")

#grid(columns: (1fr, 2.2in), column-gutter: 0.28in,
  [
    En septiembre empecé a contar en público cómo se hace el juego de ejemplo: un devlog cada lunes, con un GIF del avance y una pregunta para la comunidad. Sin anuncios, solo constancia.

    El resultado del mes: *#miles(total-visitas) visitas* a la página del juego y *#total-wl wishlists*. La semana 4 tuvo cuatro veces las visitas de la semana 1.

    #sub("Qué cambió cada semana", "what changed each week")
    #checklist((
      (true, [Sem 1: primer devlog, solo texto.], none),
      (true, [Sem 2: agregué un GIF jugable.], none),
      (true, [Sem 3: pregunta abierta a la comunidad.], none),
      (true, [Sem 4: el devlog llegó a un foro grande.], none),
    ))
  ],
  [
    #v(0.05in)
    #nota-datos("Números del mes", "Numbers of the month", (
      ([#miles(total-visitas)], [visitas · visits]),
      ([#total-wl], [wishlists]),
      ([#conv(total-visitas, total-wl)], [conversión · conversion]),
      ([4×], [sem 4 vs. sem 1]),
    ))
  ],
)

#v(0.1in)
#sub("Visitas por semana", "weekly visits, sketched")
#grid(columns: (1fr, 2.05in), column-gutter: 0.22in, align: (left + top, left + top),
  grafica-barras(visitas, alto: 2.75in, resaltar: 3, formato: v => miles(v),
    nota-clave: [la semana 4 trajo el 42% de las visitas del mes],
    pie: [Suma de las 4 barras: #miles(total-visitas) visitas]),
  [
    #v(0.1in)
    #foto("assets/moki-v001-telescopio-grafica.jpg", width: 1.9in, rot: 2deg, pie: [Moki mira la tendencia])
  ],
)

#v(0.12in)
#v(0.1in)
#moki-senala(ancho-moki: 1.05in)[
  #nota([La gente no llegó por el anuncio, llegó por el GIF jugable. Mostrar el juego vale más que describirlo.], size: 10.5pt)
  #v(-4pt)
  #en[Key insight: showing the game beats describing it.]
]


#pagebreak(weak: true)

// ---------- 4 · Tabla, aprendizajes, idea clave ----------
#entrada-titulo("Entrada 02 · miércoles 14 de octubre, 2026", "La primera cima: 800 wishlists", "The first summit: 800 wishlists")

#grid(columns: (1fr, 2.5in), column-gutter: 0.28in, align: (left + top, left + top),
  [
    Una wishlist es una promesa: alguien quiere que le avise cuando el juego salga. Por eso la mido igual que una venta futura.

    #sub("Wishlists por semana", "wishlists per week")
    #table(columns: (1fr, auto, auto, auto), stroke: none, inset: (x: 4pt, y: 5pt), align: (left, right, right, right),
      table.hline(stroke: trazo),
      [#nota[Semana]], [#nota[Visitas]], [#nota[Wishlists]], [#nota[Conv.]],
      table.hline(stroke: (paint: tinta, thickness: 0.5pt)),
      ..visitas.zip(wishlists).map(((d, w)) => ([#d.at(0)], [#miles(d.at(1))], [#w], [#conv(d.at(1), w)])).flatten(),
      table.hline(stroke: trazo),
      [*Total*], [*#miles(total-visitas)*], [*#total-wl*], [*#conv(total-visitas, total-wl)*],
    )
    #align(right, ejemplo)
  ],
  [
    #v(0.1in)
    #foto("assets/moki-v001-bandera-cuadernos.jpg", width: 2.5in, rot: -2.5deg, pie: [Moki planta la bandera])
  ],
)

#sub("Lo que aprendí", "what I learned")
#grid(columns: (1fr, 1fr), column-gutter: 0.25in,
  checklist((
    (true, [*Videojuegos:* el GIF jugable duplicó el tiempo en página.], [Playable GIFs work.]),
    (true, [*Negocio:* la conversión se mantuvo cerca de 7% cada semana.], [Steady conversion.]),
  )),
  checklist((
    (true, [*IA:* resumir comentarios me ahorró una hora por devlog.], [Faster comment review.]),
    (false, [Falta medir de dónde llega cada visita.], [Track traffic sources.]),
  )),
)

#moki-asoma(etiqueta: [Idea clave · key insight], ancho-moki: 1.05in)[
  #nota[La conversión casi no cambió: lo que creció fue el tráfico. El siguiente paso no es mejorar la página, es llevar más gente a ella.]
  #v(-2pt)
  #en[Conversion stayed flat, traffic grew. Next: more reach, not a new page.]
]

#v(0.1in)
#sub("Mis notas", "my notes")
#renglones(3)

#pagebreak(weak: true)

// ---------- 5 · Cierre ----------
#entrada-titulo("Entrada 03 · viernes 16 de octubre, 2026", "La siguiente ruta", "The next route")

Un mes no prueba nada por sí solo, pero ya marca un camino. La siguiente etapa repite lo que funcionó y cambia una sola cosa: dónde se publica el devlog.

#v(0.05in)
#grid(columns: (1fr, 2.5in), column-gutter: 0.3in, align: (left + top, left + top),
  [
    #sub("Siguientes pasos", "next steps")
    #checklist((
      (false, [*Lunes:* devlog 5 con el nuevo nivel.], [Devlog 5, new level.]),
      (false, [*Martes:* publicarlo también en dos foros nuevos.], [Two new forums.]),
      (false, [*Viernes:* medir visitas por fuente.], [Measure traffic by source.]),
      (false, [*Meta del mes:* 1,500 wishlists.], [Goal: 1,500 wishlists.]),
    ), espacio: 6pt)
    #v(0.15in)
    #post-it(width: 3.1in, rot: -1.5deg, fill: post-crema)[
      #mano([Regla de la libreta], size: 17pt, fill: tinta)
      #v(-4pt)
      #nota[Un cambio a la vez. Si cambio tres cosas, no sabré cuál funcionó.]
      #v(-2pt)
      #en[One change at a time.]
    ]
  ],
  [
    #v(0.25in)
    #foto("assets/moki-v001-mapa-siguiente-paso.jpg", width: 2.5in, rot: 2deg, pie: [Moki marca el siguiente paso])
  ],
)

#v(0.1in)
#sub("Preguntas para el lunes", "questions for Monday")
#nota([¿Qué foro trae visitas que sí agregan el juego a su lista?], size: 10.5pt)
#renglones(3, sep: 0.24in)

#v(0.1in)
#firma()
#cierre-pie()
