#!/usr/bin/env bash
# Uso: ./build.sh [archivo.typ] [salida.pdf]
# Compila con las fuentes de esta carpeta. Si existen pdfinfo y pdftoppm, reporta páginas y genera vistas de las págs. 1 y 3.
set -euo pipefail
cd "$(dirname "$0")"
SRC="${1:-ejemplo.typ}"
OUT="${2:-reporte.pdf}"

if ! command -v typst >/dev/null 2>&1; then
  echo "Typst no está en el PATH. Instálalo desde https://github.com/typst/typst/releases" >&2
  exit 1
fi

typst compile --root . --font-path fonts "$SRC" "$OUT"
echo "Listo: $OUT"

if command -v pdfinfo >/dev/null 2>&1; then
  echo "Páginas: $(pdfinfo "$OUT" | awk '/Pages/{print $2}')"
fi

if command -v pdftoppm >/dev/null 2>&1; then
  BASE="${OUT%.pdf}"
  for P in 1 3; do
    pdftoppm -png -r 120 -f "$P" -l "$P" -singlefile "$OUT" "$BASE-p$P"
  done
  echo "Vistas: ${BASE}-p1.png ${BASE}-p3.png"
fi
