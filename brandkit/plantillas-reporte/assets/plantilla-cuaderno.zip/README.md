# Plantilla «Cuaderno de campo» / Field notebook template

Plantilla oficial de reportes de la marca personal **Jorge Suárez** (JorgeSuarez.com.mx).
Official report template for the **Jorge Suárez** personal brand only.

Cada reporte se lee como el preludio o un capítulo de un libro: con carácter, e imprimible.
Each report reads like a book chapter: characterful, and printable.

## Solo esta marca / This brand only

**Sí / Use for:** documentos y reportes de la marca personal de Jorge Suárez: bitácoras, capítulos, ebooks y reportes de aprendizaje de JorgeSuarez.com.mx.

**No / Do not use for:** Amber, Arden, Sparkplug, Tecni Moto ni ninguna otra marca o empresa. Esas identidades no usan este estilo, ni a Moki, ni la firma JorgeSuarez.com.mx.

## Cómo hacer un reporte nuevo / How to make a new report

1. Copia esta carpeta completa. / Copy this whole folder.
2. Renombra `ejemplo.typ` y reemplaza el contenido. Conserva `#import "cuaderno.typ": *` y el bloque `#show: cuaderno.with(...)`.
3. Prepara 3 o 4 ilustraciones nuevas de Moki para ese texto y guárdalas en `assets/`.
4. Compila: `./build.sh mi-reporte.typ mi-reporte.pdf`
5. Revisa el PDF en carta, en color y en escala de grises.

Requisito: [Typst](https://github.com/typst/typst/releases) en el PATH. El script corre `typst compile --root . --font-path fonts`.

## Qué no hacer / What not to do

- No usar este estilo fuera de la marca personal de Jorge Suárez.
- No voltear a Moki ni girarlo más de 8 grados. La plantilla limita el giro.
- No tapar texto con Moki. La cinta siempre sostiene una foto o una nota; nunca va suelta.
- No inventar cifras sin marcarlas como datos de ejemplo.
- No recortar la página ni poner fondos oscuros a sangre.
- Español primero, con subtítulos en inglés. / Spanish first, with English subtitles.

## Qué hay en la carpeta / Folder contents

| Archivo | Uso / Purpose |
| --- | --- |
| `cuaderno.typ` | Funciones de la plantilla. / Template functions. |
| `ejemplo.typ` | Muestra que usa las funciones y las poses de `assets/`. / Sample that uses the functions and the poses in `assets/`. |
| `build.sh` | Compila el PDF. / Compiles the PDF. |
| `assets/` | Poses de Moki y la firma. / Moki poses and the signature. |
| `fonts/` | Outfit, Inter, Caveat y Kalam, con `OFL.txt`. |

## Funciones / Functions

`cuaderno.with`, `portada`, `indice`, `entrada-titulo`, `sub`, `nota-datos`, `grafica-barras`, `checklist`, `foto`, `moki-asoma`, `moki-senala`, `nota-margen`, `post-it`, `renglones`, `firma`, `cierre-pie`, `ejemplo`, `miles`.

## Fuentes / Fonts

Las cuatro fuentes van en `fonts/` bajo SIL Open Font License 1.1. Ver `fonts/OFL.txt`.

| Fuente | Uso | Origen oficial |
| --- | --- | --- |
| Outfit | Títulos | [Outfit Fonts](https://github.com/Outfitio/Outfit-Fonts) |
| Inter | Texto | [Inter](https://github.com/rsms/inter) |
| Caveat | Acentos a mano | [Caveat](https://github.com/googlefonts/caveat) · [Google Fonts](https://fonts.google.com/specimen/Caveat) |
| Kalam | Notas | [Indian Type Foundry](https://github.com/itfoundry/kalam) · [Google Fonts](https://fonts.google.com/specimen/Kalam) |

Si falta alguna, descárgala de su origen oficial y colócala en `fonts/` sin cambiarle el nombre de familia.

## Ilustraciones / Illustrations

Cada reporte lleva 3 o 4 imágenes nuevas de Moki haciendo lo que cuenta el texto. Referencia: las poses `assets/moki-*.png`. Moki es un astronauta de cartón naranja, casco crema, visor oscuro y parche MOKI sobre su oreja derecha. Nunca personas reales.

## Antes de entregar / Before you ship

- 4 a 6 páginas carta, márgenes seguros, nada cortado.
- Datos de ejemplo marcados en portada y en cada caja de datos o gráfica.
- Legible en escala de grises.
- Sin guion largo, sin «Próximamente», sin notas internas.
